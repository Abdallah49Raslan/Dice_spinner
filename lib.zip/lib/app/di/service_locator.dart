import 'package:dice/features/liars_dice/data/repositories/liars_dice_history_repo_impl.dart';
import 'package:dice/features/liars_dice/domain/repositories/liars_dice_history_repo.dart';

import '../../features/liars_dice/data/datasources/local/liars_dice_history_storage.dart';

class ServiceLocator {
  ServiceLocator._();

  static final LiarsDiceHistoryStorage _liarsDicePresetsStorage =
      LiarsDiceHistoryStorage();

  static final LiarsDicePresetsRepo _liarsDicePresetsRepo =
      LiarsDicePresetsRepoImpl(_liarsDicePresetsStorage);

  static LiarsDicePresetsRepo get liarsDicePresetsRepo => _liarsDicePresetsRepo;
}
