import 'package:dice/features/liars_dice/domain/actions/game_action.dart';

class NextRoundAction extends GameAction {
  const NextRoundAction();
}