abstract class GameAction {
  const GameAction();
}