import 'package:dice/features/liars_dice/domain/actions/game_action.dart';

class ConfirmNextAction extends GameAction {
  const ConfirmNextAction();
}