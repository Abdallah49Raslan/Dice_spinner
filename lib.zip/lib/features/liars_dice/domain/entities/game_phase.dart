enum GamePhase {
  rolling,   // كل اللاعبين بيرموا
  betting,   // المزايدات شغالة
  reveal,    // كشف النرد بعد Call
  roundEnd,  // تحديد الخاسر والتحضير للجولة الجديدة
}
