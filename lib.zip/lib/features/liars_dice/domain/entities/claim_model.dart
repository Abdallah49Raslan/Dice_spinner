class ClaimModel {
  final int quantity;
  final int face;

  ClaimModel({
    required this.quantity,
    required this.face,
  });
}
