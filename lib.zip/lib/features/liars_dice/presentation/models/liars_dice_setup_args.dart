class LiarsDiceSetupArgs {
  final List<String> players;

  LiarsDiceSetupArgs({
    required this.players,
  });
}
